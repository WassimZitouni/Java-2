import java.util.ArrayList;

public class java6a
 {
    public static void main(String[] args) 
    {
        // arrayList of cars
        ArrayList<String> cars = new ArrayList<>();
        cars.add("Monte Carlo");
        cars.add("Corvette");
        cars.add("Ferrari");
        cars.add("Lamborghini");
        cars.add("Viper");
        cars.add("Mustang GT");
        cars.add("Camaro");
        cars.add("Porsche");
        cars.add("Taurus");
        cars.add("Lexus");
        // print list of cars
        System.out.println("List of Cars");
        System.out.println("------------");
        for (String car : cars) 
        {
            System.out.println(car);
        }
        System.out.println();

        // favorite car
        cars.set(0, "Outlander");
        // 6th car
        cars.add(5, "Infiniti");
        // delete taurus
        cars.remove("Taurus");
        System.out.println("Updated List of Cars");
        System.out.println("--------------------");
        for (String car : cars) 
        {
            System.out.println(car);
        }
    }
}
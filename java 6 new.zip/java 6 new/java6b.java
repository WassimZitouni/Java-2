public class java6b 
{
    public static void main(String[] args) 
    {
        // array of employee objects 5 occurrences
        Employee[] employees = new Employee[5];
        
        employees[0] = new Employee("Sourav Chatterjee", "NC", 60000.0, 3, 'M');
        employees[1] = new Employee("Michel Fathi", "VA", 15000.0, 1, 'S');
        employees[2] = new Employee("Vess Johnson", "NC", 125000.0, 0, 'M');
        employees[3] = new Employee("Dipak Pravin", "NJ", 150000.0, 2, 'S');
        employees[4] = new Employee("Laurie Giddens", "NJ", 280000.0, 3, 'M');
        
        // employee payroll array
        for (int i = 0; i < employees.length; i++) {
            Employee currentEmployee = employees[i];
            System.out.println("Employee " + (i + 1) + " Details:");
            System.out.println("Name: " + currentEmployee.getName());
            System.out.println("State: " + currentEmployee.getState());
            System.out.printf("Salary: $%,.2f%n", currentEmployee.getSalary());
            System.out.println("Exempts: " + currentEmployee.getExempts());
            System.out.println("Marital Status: " + currentEmployee.getMaritalStatus());
            System.out.printf("Fed Tax: $%,.2f%n", currentEmployee.getFedTax());
            System.out.printf("State Tax: $%,.2f%n", currentEmployee.getStateTax());
            System.out.printf("Net Income: $%,.2f%n%n", currentEmployee.getNetIncome());
        }
    }
}